//
// import 'package:flutter/material.dart';
// import 'mini_list.dart';
//
// void main(){
//   runApp(AddMini());
// }
//
// class AddMini extends StatelessWidget {
//   const AddMini({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: MiniList(),
//     );
//   }
// }
