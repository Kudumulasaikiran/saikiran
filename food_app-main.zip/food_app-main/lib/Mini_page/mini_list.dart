import 'package:flutter/material.dart';

import '../New_Cart/Cart_page.dart';

final _formkey = GlobalKey<FormState>();

class MiniList extends StatefulWidget {
  const MiniList({super.key});

  @override
  State<MiniList> createState() => _MiniListState();
}

class _MiniListState extends State<MiniList> {
  List<String> AllFirstText = [
    'Food Studio',
    'Roll Express',
    'Grill Masters',
    'PUBG Cafe',
    'Royal Chicken',
  ];
  List<String> AllSecondText = [
    '13th street,47 W 13th st,NY',
    '78th sreet,88 W 21th st,NY',
    '132th street,41 W 10th st,NY',
    '13th street,47 W 13th st,NY',
    '78th sreet,88 W 21th st,NY',
  ];
  List<String> AllThirdText = [
    '3 min 300 m',
    '4 min 400 m ',
    '5 min 500 m ',
    '3 min 500 m ',
    '4 min 400 m',
  ];

  List<String> AllImage = [
    'assets/images/food1.png',
    'assets/images/food2.png',
    'assets/images/food3.png',
    'assets/images/food4.png',
    'assets/images/food1.png',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
            onPressed: () {
              if (_formkey.currentState!.validate())
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => CartPage()));
            },
            icon: Icon(Icons.arrow_back_ios_sharp)),
        centerTitle: true,
        title: Text('Near 500 m Shops'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 15),
          child: Form(
            key: _formkey,
            child: Column(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.0),
                  child: Row(
                    children: [
                      Container(
                        height: 50,
                        width: 50,
                        color: Colors.transparent,
                        child: Image.asset(
                          'assets/images/Cart.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 10, left: 15),
                        child: Column(
                          children: [
                            Text(
                              'Awesome Fruit Restaurant',
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                            Padding(
                              padding: EdgeInsets.only(right: 45),
                              child: Text(
                                'Available Shop in near 5',
                                style: TextStyle(color: Colors.grey.shade800),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                    padding: EdgeInsets.only(top: 10, left: 10, right: 25),
                    child: ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: 5,
                        itemBuilder: (BuildContext context, int index) {
                          return Padding(
                            padding: EdgeInsets.only(bottom: 10),
                            child: Container(
                              height: 120,
                              width: 300,
                              color: Colors.white,
                              child: Row(
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: 15),
                                    child: Container(
                                      height: 80,
                                      width: 80,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        image: DecorationImage(
                                            image: AssetImage(AllImage[index]),
                                            fit: BoxFit.cover),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(left: 10, top: 18),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          AllFirstText[index],
                                          style: TextStyle(fontSize: 18),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(top: 5),
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.location_on,
                                                color: Colors.grey,
                                                size: 12,
                                              ),
                                              Text(
                                                AllSecondText[index],
                                                style: TextStyle(
                                                    color: Colors.grey,
                                                    fontSize: 12),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(top: 5),
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.access_time,
                                                color: Colors.grey,
                                                size: 12,
                                              ),
                                              Padding(
                                                padding: EdgeInsets.symmetric(
                                                    horizontal: 5.0),
                                                child: Text(
                                                  AllThirdText[index],
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 12),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(top: 5),
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.star,
                                                color: Colors.yellow,
                                                size: 12,
                                              ),
                                              Text('4.9',
                                                  style: TextStyle(
                                                      color: Colors.black,
                                                      fontSize: 12)),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 170),
                                                child: Icon(
                                                  Icons.favorite_border,
                                                  size: 18,
                                                  color: Colors.grey,
                                                ),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
