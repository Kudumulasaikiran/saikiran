import 'package:flutter/material.dart';

class MiniPage extends StatelessWidget {
  const MiniPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.grey.shade100,
        appBar: AppBar(
          backgroundColor: Colors.grey.shade100,
          leading: IconButton(
              onPressed: () {}, icon: Icon(Icons.arrow_back_ios_sharp)),
          centerTitle: true,
          title: Text('Near 500 m Shops'),
        ),
        body: SingleChildScrollView(
            child: Padding(
              padding:  EdgeInsets.symmetric(horizontal: 15.0,vertical: 15),
              child: Column(
                  children: [
                        Row(
              children: [
                Container(
                  height: 50,
                  width: 50,
                  color: Colors.transparent,
                  child: Image.asset(
                    'assets/images/Cart.png',
                    fit: BoxFit.cover,
                  ),
                ),
                Padding(
                  padding:  EdgeInsets.only(bottom: 10, left: 15),
                  child: Column(
                    children: [
                       Text(
                        'Awesome Fruit Restaurant',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      Padding(
                        padding:  EdgeInsets.only(right: 45),
                        child: Text(
                          'Available Shop in near 5',
                          style: TextStyle(color: Colors.grey.shade800),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
                        ),
                      ]
              ),
            )
        )
    );
  }
}
