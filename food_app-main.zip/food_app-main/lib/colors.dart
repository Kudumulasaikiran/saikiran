import 'package:flutter/material.dart';

Color homeIconColor = Color(0xFFF57D1F);
Color homeIconBgColor = Color(0xFFB0F3F3);
Color primaryContColor = Color(0xFFB9FFB3);
Color primaryTextColor = Color(0xFFB0EAE00);
Color bgColor = Color(0xFFB0F6FB);
Color perTextColor = Color(0xFF808D9E);
Color cartContainerColor = Color(0xFFC2C2C2);
Color CartSmallTextColor = Color(0xFF565656);
Color CartPageMainText = Color(0xFF282828);
Color CartPageBoldText = Color(0xFF282828);
Color CartPageDarkText = Color(0xFF000000);
Color CartText = Color(0xFF000000);
Color SeeNearCartColor = Color(0xFFFF8C00);
Color BillDetailsTextColor = Color(0xFF5D5D5D);
Color wefrgthy = Color(0xFFF455);
Color efrgthyj = Color(0xF57D1F);


