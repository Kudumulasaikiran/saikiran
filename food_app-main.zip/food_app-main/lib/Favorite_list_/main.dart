// import 'package:flutter/material.dart';
//
// import 'favorite_list_page.dart';
//
// void main(){
//   runApp(FavoriteList());
// }
// class FavoriteList extends StatelessWidget {
//
//    FavoriteList ({super.key});
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: FavoriteListPage(),
//     );
//   }
// }
