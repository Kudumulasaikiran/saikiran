import 'package:flutter/material.dart';

import '../colors.dart';

class RestFoodContainer extends StatefulWidget {
  const RestFoodContainer({super.key});

  @override
  State<RestFoodContainer> createState() => _RestFoodContainerState();
}

class _RestFoodContainerState extends State<RestFoodContainer> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.0),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 20.0),
              child: Row(
                children: [
                  Padding(
                    padding: EdgeInsets.only(right: 20.0),
                    child: Image.asset(
                      'assets/images/foodtruckicon.png',
                      height: 50,
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Awesome Fruit Restaurant',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      Row(
                        children: [
                          Text(
                            'Extra 10 mins',
                            style: TextStyle(color: Colors.grey.shade800),
                          ),
                          SizedBox(width: 5),
                          Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: primaryContColor),
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 15.0, vertical: 2),
                              child: Center(
                                child: Text("Primary",
                                    style: TextStyle(color: primaryTextColor)),
                              ),
                            ),
                          )
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 20.0),
              child: CartItemContainer(
                foodName: 'Biriyani',
                foodCost: 250,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 20.0),
              child: CartItemContainer(
                foodName: 'Biriyani',
                foodCost: 250,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Total amount in this shop",
                  style: TextStyle(
                      color: CartPageDarkText,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                Text(
                  "Rs 500",
                  style: TextStyle(
                      color: CartPageDarkText,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}

class CartItemContainer extends StatefulWidget {
  final String foodName;
  final int foodCost;

  const CartItemContainer(
      {super.key, required this.foodName, required this.foodCost});

  @override
  State<CartItemContainer> createState() => _CartItemContainerState();
}

class _CartItemContainerState extends State<CartItemContainer> {
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return Container(
      height: 45,
      width: screenWidth,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          border: Border.all(color: cartContainerColor)),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              widget.foodName,
              style: TextStyle(color: CartSmallTextColor),
            ),
            Text(
              "₹ ${widget.foodCost}",
              style: TextStyle(color: CartSmallTextColor),
            ),
            AddRemoveButton(),
          ],
        ),
      ),
    );
  }
}

class AddRemoveButton extends StatefulWidget {
  const AddRemoveButton({super.key});

  @override
  State<AddRemoveButton> createState() => _AddRemoveButtonState();
}

class _AddRemoveButtonState extends State<AddRemoveButton> {
  int count = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
        child: Row(
      children: [
        GestureDetector(
          child: Icon(Icons.remove_circle, color: Colors.orange),
          onTap: () {
            setState(() {
              if (count > 0) count--;
            });
          },
        ),
        Text(
          "$count",
          style: TextStyle(color: CartPageBoldText),
        ),
        GestureDetector(
          child: Icon(Icons.add_circle, color: Colors.orange),
          onTap: () {
            setState(() {
              count++;
            });
          },
        ),
      ],
    ));
  }
}
