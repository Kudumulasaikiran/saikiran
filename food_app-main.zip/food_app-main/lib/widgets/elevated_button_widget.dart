import 'package:flutter/material.dart';

class ElevatedButtonWidget extends StatefulWidget {
  final VoidCallback onPressed;
  final double height;
  final double width;
  final String text;

  const ElevatedButtonWidget({
    super.key,
    required this.onPressed,
    required this.text,
    required this.height,
    required this.width,
  });

  @override
  State<ElevatedButtonWidget> createState() => _ElevatedButtonWidgetState();
}

class _ElevatedButtonWidgetState extends State<ElevatedButtonWidget> {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: widget.onPressed,
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        elevation: 0,
      ),
      child: Ink(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.yellow, Colors.orange.shade900],
          ),
          borderRadius: BorderRadius.circular(30),
        ),
        child: Container(
          height: widget.height,
          width: widget.width,
          alignment: Alignment.center,
          child: Text(
            widget.text,
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
    );
  }
}

class ElevatedMiniButtonWidget extends StatefulWidget {
  final double height;
  final double? height1;
  final VoidCallback onPressed;
  final double width;
  final String text;

  const ElevatedMiniButtonWidget(
      {super.key,
      required this.text,
      required this.height,
      required this.width,
      required this.onPressed,
      this.height1});

  @override
  State<ElevatedMiniButtonWidget> createState() =>
      _ElevatedMiniButtonWidgetState();
}

class _ElevatedMiniButtonWidgetState extends State<ElevatedMiniButtonWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: widget.height,
      width: widget.width,
      alignment: Alignment.center,
      child: ElevatedButton(
        onPressed: widget.onPressed,
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ),
          elevation: 0,
          padding: EdgeInsets
              .zero, // Remove default padding to match the container's size
        ),
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.yellow,
                Colors.orange.shade900,
              ],
            ),
            borderRadius: BorderRadius.circular(30),
          ),
          child: Container(
            alignment: Alignment.center,
            height: widget.height1,
            width: 150,
            child: Text(
              widget.text,
              style: TextStyle(color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}

class ElevatedBlankButtonWidget extends StatefulWidget {
  final double height;
  final double? height1;
  final double width;
  final String text;
  final Color color;
  final VoidCallback onPressed;

  const ElevatedBlankButtonWidget(
      {super.key,
      required this.text,
      required this.height,
      this.height1,
      required this.width,
      required this.onPressed,
      required this.color});

  @override
  State<ElevatedBlankButtonWidget> createState() =>
      _ElevatedBlankButtonWidgetState();
}

class _ElevatedBlankButtonWidgetState extends State<ElevatedBlankButtonWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: widget.height,
      width: widget.width,
      alignment: Alignment.center,
      child: ElevatedButton(
        onPressed: widget.onPressed,
        style: OutlinedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ),
          side: BorderSide(color: widget.color),
        ),
        child: Container(
          alignment: Alignment.center,
          height: widget.height1,
          width: widget.width,
          child: Text(
            widget.text,
            style: TextStyle(color: widget.color),
          ),
        ),
      ),
    );
  }
}
