
import 'package:flutter/material.dart';
TextStyle  style=
TextStyle(color: Colors.white,
  fontWeight: FontWeight.bold,fontSize: 27,);
TextStyle style2 =
TextStyle(color: Colors.white, fontSize: 14,
);
TextStyle style3= TextStyle(
  color:Colors.white,
  fontWeight: FontWeight.bold,
  fontSize: 18.0,
);
TextStyle  style4=
TextStyle(color: Colors.black,
  fontWeight: FontWeight.bold,fontSize: 19);
TextStyle style5 =
TextStyle(color: Colors.orange,
  fontWeight: FontWeight.bold,fontSize: 11,
);
TextStyle style6= TextStyle(
  color:Colors.black,
  fontWeight: FontWeight.bold,
  fontSize: 18.0,
);
TextStyle style7= TextStyle(
  color:Colors.grey,
  fontWeight: FontWeight.bold,
  fontSize: 10,
);
TextStyle style8= TextStyle(
  color:Colors.black,
  fontWeight: FontWeight.bold,
  fontSize: 18.0,
);
TextStyle style9= TextStyle(
  color:Colors.black,
  fontSize: 15.0,
);
TextStyle style10= TextStyle(
  color:Colors.white,
  fontSize: 15.0,
);
TextStyle style11= TextStyle(
  fontWeight: FontWeight.bold,
  color:Colors.white,
  fontSize: 16.0,
);
TextStyle style12= TextStyle(
  color:Colors.grey,
  fontSize: 14.0,
);
TextStyle style13= TextStyle(
fontWeight: FontWeight.bold,
color:Colors.black,
fontSize: 14.0,
);
TextStyle style14= TextStyle(
  color:Colors.black,
  fontSize: 16.0,
);



