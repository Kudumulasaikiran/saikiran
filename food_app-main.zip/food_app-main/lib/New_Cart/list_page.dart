import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class VerticalDottedLine extends StatelessWidget {
  final double height;
  final Color color;

  VerticalDottedLine({this.height = 200.0, this.color = Colors.black});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      child: CustomPaint(
        painter: VerticalDottedLinePainter(color),
      ),
    );
  }
}

class VerticalDottedLinePainter extends CustomPainter {
  final Color color;

  VerticalDottedLinePainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;

    const double dashHeight = 3.0;
    const double dashSpace = 1.0;
    double currentY = 0.0;
    bool isDash = true;

    while (currentY < size.height) {
      if (isDash) {
        canvas.drawLine(
          Offset(0, currentY),
          Offset(0, currentY + dashHeight),
          paint,
        );
      }
      currentY += dashHeight + dashSpace;
      isDash = !isDash;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}