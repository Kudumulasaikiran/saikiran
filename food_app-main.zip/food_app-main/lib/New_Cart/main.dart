// import 'package:flutter/material.dart';
// import 'Cart_page.dart';
// void main(){
//   runApp(AddCart());
// }
// class AddCart extends StatelessWidget {
//   const AddCart({super.key});
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: CartPage(),
//     );
//   }
// }
//
