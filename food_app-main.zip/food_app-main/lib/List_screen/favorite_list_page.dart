import 'package:flutter/material.dart';
import 'fav_bottom_nav.dart';
import 'favorite_icon.dart';
class FavoriteListPage extends StatefulWidget {
  const FavoriteListPage({super.key});

  @override
  State<FavoriteListPage> createState() => _FavoriteListPageState();
}

class _FavoriteListPageState extends State<FavoriteListPage> {
  List<String> AllFirstText = [
    'Awesome Fruit Restaurant',
    'Pizza Lover Company',
    'Chicken Fried Restaurant',
    'Awesome Fruit Restaurant',
    'Pizza Lover Company',
    'Chicken Fried Restaurant',
  ];
  List<String> AllSecondText = [
    '13th street,47 W 13th st,NY',
    '78th sreet,88 W 21th st,NY',
    '132th street,41 W 10th st,NY',
    '13th street,47 W 13th st,NY',
    '78th sreet,88 W 21th st,NY',
    '132th street,41 W 10th st,NY',
  ];
  List<String> AllThirdText = [
    '3 min,1.1 km',
    '4 min,1.5 km',
    '5 min,1.7 km',
    '3 min,1.1 km',
    '4 min,1.5 km',
    '5 min,1.7 km',
  ];
  List<String> AllImage = [
    'assets/images/fruits.png',
    'assets/images/pizaa.png',
    'assets/images/pizaa.png',
    'assets/images/fruits.png',
    'assets/images/pizaa.png',
    'assets/images/fruits.png',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text('Favourite'),
        leading: Padding(
          padding: EdgeInsets.only(left: 320.0),
          child: IconButton(onPressed: () {}, icon: Icon(Icons.search)),
        ),
      ),
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 10, left: 40, right: 1),
              child: ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: 6,
                itemBuilder: (BuildContext context, int index) {
                  return Padding(
                    padding: EdgeInsets.only(bottom: 10),
                    child: Container(
                      height: 150,
                      width: 490,
                      color: Colors.white,
                      child: Row(
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 15),
                            child: Container(
                              height: 80,
                              width: 80,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                image: DecorationImage(
                                  image: AssetImage(AllImage[index]),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            // Add Expanded widget here
                            child: Padding(
                              padding: EdgeInsets.only(left: 10, top: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    AllFirstText[index],
                                    style: TextStyle(fontSize: 15),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(top: 5),
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.location_on,
                                          color: Colors.grey,
                                          size: 12,
                                        ),
                                        Text(
                                          AllSecondText[index],
                                          style: TextStyle(
                                            color: Colors.grey,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(top: 5),
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.access_time,
                                          color: Colors.grey,
                                          size: 12,
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(left: 5.0),
                                          child: Text(
                                            AllThirdText[index],
                                            style: TextStyle(
                                              color: Colors.grey,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(top: 5),
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.star,
                                          color: Colors.yellow,
                                          size: 12,
                                        ),
                                        Text(
                                          '4.9',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 12,
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(left: 140),
                                          child: FavoriteButton(),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      // bottomNavigationBar: FavCustomBottomBar(),
    );
  }
}
