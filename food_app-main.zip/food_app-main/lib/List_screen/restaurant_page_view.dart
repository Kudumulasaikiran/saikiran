import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Custom_BottomNavigationBar.dart';
import 'carousel_slider.dart';
import 'custom_container.dart';

class RestaurantPageView extends StatefulWidget {
  const RestaurantPageView({super.key});

  @override
  State<RestaurantPageView> createState() => _RestaurantPageViewState();
}

class _RestaurantPageViewState extends State<RestaurantPageView> {
  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery.of(context).size.width;
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          leading: Icon(
            Icons.arrow_back_ios_new,
          ),
          actions: [
            Row(
              children: [
                IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.favorite_border,
                  ),
                ),
                IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.search,
                  ),
                ),
                IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.share,
                  ),
                )
              ],
            )
          ],
        ),
        body: SingleChildScrollView(
            child: Column(children: [
          MyHomepage(),
          Container(
            width: ScreenWidth,
            height: 200,
            padding: EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Awesome Fruit Restaurant',
                        style: TextStyle(
                          fontSize: 25.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Row(
                        children: [
                          Padding(
                            padding: EdgeInsets.only(top: 8.0),
                            child: Icon(
                              Icons.star,
                              color: Colors.yellow,
                              size: 25,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 8.0),
                            child: Icon(
                              Icons.star,
                              color: Colors.yellow,
                              size: 25,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 8.0),
                            child: Icon(
                              Icons.star,
                              color: Colors.yellow,
                              size: 25,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 8.0),
                            child: Icon(
                              Icons.star,
                              color: Colors.yellow,
                              size: 25,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 8.0),
                            child: Icon(
                              Icons.star,
                              color: Colors.yellow,
                              size: 25,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 8.0, top: 8.0),
                            child: Text(
                              '4.9-1220 Reviews',
                              style: TextStyle(fontSize: 15),
                            ),
                          )
                        ],
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 8.0),
                        child: Text(
                          'Type of Cuisines',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 8.0),
                        child: Row(
                          children: [
                            Icon(
                              Icons.access_time,
                              size: 18,
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 8.0),
                              child: Text(
                                'open 7:00 - 21:00',
                                style: TextStyle(fontSize: 15),
                              ),
                            )
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 8.0),
                        child: Row(
                          children: [
                            Icon(
                              Icons.location_on_outlined,
                              size: 18,
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 8.0),
                              child: Text(
                                '78th Street.88 W 21th st,NY',
                                style: TextStyle(fontSize: 15),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Padding(
                padding: EdgeInsets.only(top: 18.0),
                child: Container(
                  height: 50,
                  width: 350,
                  color: Colors.white,
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              color: Colors.grey,

                              width: 2, // specify the border width here
                            ),
                            borderRadius: BorderRadius.circular(
                                30), // specify border radius here if needed
                          ),
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white,
                              ),
                              onPressed: () {},
                              child: Row(
                                children: [
                                  Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Icon(
                                        Icons.crop_square_sharp,
                                        color: Colors.green,
                                        size: 25,
                                      ),
                                      Icon(Icons.circle,
                                          color: Colors.green, size: 10),
                                    ],
                                  ),
                                  Text("Veg")
                                ],
                              )),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              color: Colors.grey,
                              // specify the border color here
                              width: 2, // specify the border width here
                            ),
                            borderRadius: BorderRadius.circular(
                                30), // specify border radius here if needed
                          ),
                          child: ElevatedButton(
                              onPressed: () {},
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white,
                              ),
                              child: Row(
                                children: [
                                  Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Icon(
                                        Icons.crop_square_sharp,
                                        color: Colors.red,
                                        size: 25,
                                      ),
                                      Icon(CupertinoIcons.arrowtriangle_up_fill,
                                          color: Colors.red, size: 10),
                                    ],
                                  ),
                                  Text("Non-veg")
                                ],
                              )),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              color: Colors.grey,
                              // specify the border color here
                              width: 2, // specify the border width here
                            ),
                            borderRadius: BorderRadius.circular(
                                30), // specify border radius here if needed
                          ),
                          child: ElevatedButton(
                              onPressed: () {},
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white,
                              ),
                              child: Row(
                                children: [
                                  Image.asset(
                                    'assets/images/Egg-Slice.png',
                                    width: 20,
                                    height: 20,
                                  ),
                                  Text("egg")
                                ],
                              )),
                        ),
                      ]),
                ),
              ),
            ],
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              child: Text(
                'Menu',
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: ContainerCon(),
          ),
        ])),
        bottomNavigationBar: CustomBottomBar(),
        extendBody: false,
      ),
    );
  }
}
