
import 'package:flutter/material.dart';

class CustomBottomBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70.0,
      width: double.infinity, // Adjust width to fit the screen
      padding:  EdgeInsets.symmetric(horizontal: 10),
      decoration:  BoxDecoration(
        color: Colors.white,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ShaderMask(
            shaderCallback: (Rect bounds) {
              return  LinearGradient(
                colors: [Colors.yellow, Colors.orange], // Define gradient colors
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ).createShader(bounds);
            },
            child:  Icon(
              Icons.home,
              size: 40,
              color: Colors.white, // Icon color
            ),
          ),
          IconButton(
            icon:  Icon(Icons.favorite_border_rounded, size: 40,),
            onPressed: () {
              // Add onPressed logic here
            },
          ),
           CircleAvatar(
            radius: 20,
            backgroundImage: AssetImage('assets/images/girl.jpg'),
          )
        ],
      ),
    );
  }
}





