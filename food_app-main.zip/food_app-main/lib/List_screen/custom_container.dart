import 'package:flutter/material.dart';
import 'package:food_app_new/cart_view.dart';

import '../New_Cart/Cart_page.dart';
import '../cart_page_2.dart';

class ContainerCon extends StatefulWidget {
  List image = ['assets/images/img.jpg'];

  ContainerCon({
    super.key,
  });

  @override
  State<ContainerCon> createState() => _ContainerConState();
}

class _ContainerConState extends State<ContainerCon> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        shrinkWrap: true,
        itemCount: 3,
        physics: NeverScrollableScrollPhysics(),
        itemBuilder: (BuildContext context, int index) {
          return Container(
              height: 180,
              width: 350,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(20)),
              child: Row(
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 10, top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Stack(
                              alignment: Alignment.center,
                              children: [
                                Icon(
                                  Icons.crop_square_sharp,
                                  color: Colors.green,
                                  size: 25,
                                ),
                                Icon(Icons.circle,
                                    color: Colors.green, size: 10),
                              ],
                            ),
                            Icon(
                              Icons.star,
                              color: Colors.orange,
                            ),
                            Text("4.9"),
                          ],
                        ),
                        Text(
                          "Margherita",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          "Flammkuchen",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          "₹ 250",
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        Padding(
                          padding: EdgeInsets.only(bottom: 8, top: 3),
                          child: Text(
                            "Thin crust rectangular pizza",
                            style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ),
                        Text(
                          "topped with in-house to... more",
                          style: TextStyle(fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                  ),
                  Stack(
                    children: [
                      Column(
                        children: [
                          Center(
                            child: Padding(
                              padding: EdgeInsets.only(top: 5),
                              child: Container(
                                height: 136,
                                width: 129,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  color: Colors.orange,
                                  image: DecorationImage(
                                    image: AssetImage("assets/images/img.jpg"),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Positioned(
                        top: 110,
                        left: 25,
                        child: Padding(
                          padding: EdgeInsets.only(top: 15),
                          child: Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.orange,
                              border: Border(
                                left: BorderSide(color: Colors.white, width: 3),
                                right:
                                    BorderSide(color: Colors.white, width: 3),
                                top: BorderSide(color: Colors.white, width: 3),
                                bottom:
                                    BorderSide(color: Colors.white, width: 3),
                              ),
                            ),
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => CartPage()));
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.orange,
                              ),
                              child: Icon(
                                Icons.add,
                                color: Colors.white,
                                size: 22,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ));
        });
  }
}
