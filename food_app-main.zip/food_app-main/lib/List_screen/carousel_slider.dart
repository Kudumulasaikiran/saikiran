import 'package:another_carousel_pro/another_carousel_pro.dart';
import 'package:flutter/material.dart';
import 'favorite_icon.dart';

class MyHomepage extends StatefulWidget {
  const MyHomepage({super.key});

  @override
  State<MyHomepage> createState() => _MyHomepageState();
}
class _MyHomepageState extends State<MyHomepage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Container(
            height: 350,
            child: AnotherCarousel(
              boxFit: BoxFit.fill,
              images: [
                AssetImage('assets/images/img1.jpg'),
                AssetImage('assets/images/img2.jpg'),
                AssetImage('assets/images/img3.jpg'),
              ],
              autoplay: false,
              dotColor: Colors.orange,
              dotBgColor: Colors.transparent,
            ),
          ),
        ],

      ),
    );
  }
}
